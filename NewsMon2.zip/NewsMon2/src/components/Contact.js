import React from 'react';

const Contact = ()=>{
    return (
        <div id="contact" class="container-fluid" style={{margin: 'auto'}}>
        <h1 className="text-center" style={{ margin: '35px 0px', marginTop: '90px' }}>Contact Us</h1>
  <div class="row">
  <div class="col-sm-1"></div>
    <div class="col-sm-5">
      <p> </p>
      <p><i class="bi bi-geo-alt"></i> Mumbai, India</p>
      <p><i class="bi bi-phone"></i> +00 1515151515</p>
      <p><i class="bi bi-envelope"></i> sanketmarathe@gmail.com</p>
    </div>
    <div class="col-sm-5">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="name" name="name" placeholder="Name" type="text" required/>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email" required/>
        </div>
      </div>
        <textarea class="form-control my-2" id="comments" name="comments" placeholder="Comment" rows="5"></textarea>
        <br/>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default bg-primary float-end" type="submit">Send</button>
        </div>
      </div>
    </div>
  <div class="col-sm-1"></div>
  </div>
</div>
    );
};

export default Contact;